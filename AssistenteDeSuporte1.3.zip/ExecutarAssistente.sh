java -jar /opt/sa/AssitenteDeSuporte1.3/AssistenteDeSuporte.jar
